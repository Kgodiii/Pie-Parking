package com.example.historyscreen;

public class HistoryItem {
    private String location;
    private String date;
    private String amount;

    public HistoryItem(String location, String date, String amount) {
        this.location = location;
        this.date = date;
        this.amount = amount;
    }

    public String getLocation() { return location; }
    public String getDate() { return date; }
    public String getAmount() { return amount; }
}

