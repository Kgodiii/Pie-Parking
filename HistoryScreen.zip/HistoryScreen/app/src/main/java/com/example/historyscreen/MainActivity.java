package com.example.historyscreen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerViewHistory;
    List<HistoryItem> historyList;
    HistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewHistory = findViewById(R.id.recyclerViewHistory);

        recyclerViewHistory.setLayoutManager(new LinearLayoutManager(this));

        historyList = new ArrayList<>();
        historyList.add(new HistoryItem("Mall of Africa", "12 Oct 2025", "R25.00"));
        historyList.add(new HistoryItem("Sandton City", "11 Oct 2025", "R30.00"));
        historyList.add(new HistoryItem("OR Tambo Airport", "10 Oct 2025", "R40.00"));
        historyList.add(new HistoryItem("Ennerdale Shoprite", "1 Oct 2025", "R5.00"));
        historyList.add(new HistoryItem("Sandton Gautrain", "11 Oct 2025", "R20.00"));
        historyList.add(new HistoryItem("Centurion Crossing", "10 Oct 2025", "R45.00"));


        adapter = new HistoryAdapter(historyList);
        recyclerViewHistory.setAdapter(adapter);
    }
}
